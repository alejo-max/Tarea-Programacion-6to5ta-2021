var nums;
var x;
const respuesta = document.getElementById("respuesta");
const iniciarContainer = document.getElementById("iniciarContainer");
const juego = document.querySelector(".juego");
var delay = 2000;