function GenerarNumerosAleatorios() {
    var arrayRandom = [];
    var n = 2;
    for (var i = 0; i < 9; i++) {
        var numerosRandom = [];
        for (var x = 0; x < n; x++) {
            var numAleatorio = Math.round(Math.random() * 9);
            if (numerosRandom.includes(numAleatorio) == false) {
                numerosRandom.push(numAleatorio);
            } else {
                x--;
            }
        }
        if (n <= 9) {
            n++;
        }
        arrayRandom.push(numerosRandom);
    }
    console.log(arrayRandom);
    return arrayRandom;
}


exports.GenerarNumerosAleatorios = GenerarNumerosAleatorios;